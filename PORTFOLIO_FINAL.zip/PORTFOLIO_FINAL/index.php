 <!DOCTYPE html>

 <head>
 
  <meta charset="UTF-8">
  <meta name="description" content="None">
  <meta name="keywords" content="Portfolio , Informatique">
  <meta name="author" content="Mourad">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <title>Saidani</title>

  <link rel="stylesheet" type="text/css" href="Style.css">    <!--lien vers Le css-->     
  <link rel="icon" type="images/png" href="Images/MG.png">   <!-- lien vers Les images utilisées -->

  <script src="https://kit.fontawesome.com/feb3079f35.js" crossorigin="anonymous"></script>    <!--fontawesome icons f -->

   <!-- librairie cdnjs pour jquery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>    
  <script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.11/typed.min.js"></script>   
  <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.js"></script>

</head> 



<body>

    <!--bouton scroll vers le haut-->
  
     <div class="scroll-up-btn">
        <i class="fas fa-angle-up"></i>
     </div>


     <!--Barre de navigation-->

     <nav class="navbar" >
             <div class="max-width">
                 <div class="logo"><a href="#home">Saidani Mour<span>ad</span></a></div>
                  <ul class="menu">
                    <li><a href="#home" class="menu-btn">Accueil</a></li>
                    <li><a href="#about" class="menu-btn">A-propos</a></li>
                    <li><a href="#services" class="menu-btn">Traveaux</a></li>
                    <li><a href="#skills" class="menu-btn">Compétences</a></li>
                    <li><a href="#contact" class="menu-btn">Contact</a></li>
                  </ul>
                  <div class="menu-btn">
                       <i class="fas fa-bars"></i>
                  </div>
              </div>
         </nav>




          <!--section accueil-->

        <section class="home" id="home">
              <div class="max-width">
                   <div class="home-content">
                        <div class="text-1">Salut, je m'appelle</div>
                        <div class="text-2">Saidani Mourad</div>
                        <div class="text-3">Je suis <span class="typing"></span></div>
                     
                   </div>
              </div>
           </section>




           <!--section à-propos -->

           <section class="about" id="about">
              <div class="max-width">
                   <h2 class="title">A-propos de moi</h2>
                   <div class="about-content">

                        <div class="column left">
                             <img src="Images/Me.jpg" alt="Saidani Mourad">
                        </div>

                        <div class="column right">
                            <div class="text">Je suis, <span class="typing2"></span></div>

                            <p>J'ai 20 ans, je suis étudiant en informatique. Passionné par l'art numérique et le Design Web
                               j'aime les documentaires de voyages et ceux sur la deuxième guerre mondiale mes films préferés 
                               sont (Les Evadés, Forest Gump, Retour vers le futur, Terminator 2), sans oublier les animés du Studio Ghibli.</p> 

                            <a id="download" href="download.php">Télecharger le CV</a>            
                        </div>
                             
                   </div>
              </div>

         </section>



                    <!--section Traveaux -->

          <section class="services" id="services">
              <div class="max-width">
                   <h2 class="title">Traveaux</h2>
                   <div class="serv-content">

                         <div class="card one">
                              <div class="box">                     
                                  <i class="fas fa-paint-brush"></i>
                                  <div class="text">Design Web</div> 
                                  <p><a href="https://www.instagram.com/sm_designs27/" target="_blank">Mon Instagram D'arts Degital</a></p>
                                  <a href="https://www.instagram.com/sm_designs27/" target="_blank"><img src="Images/instagram.png" width="30px"></a>
                            
                              </div>
                         </div>

                         <div class="card two">
                              <div class="box">
                                  <i class="fas fa-gamepad"></i>
                                  <div class="text">Mini Jeu</div> 
                                  <p><a href="https://github.com/mouradSai/Mini-Game-" target="_blank">Snake Game coder en C</a></p>
                                  <a href="https://github.com/mouradSai/Mini-Game-" target="_blank"><img src="Images/snake.png" width="30px"></a>
                              </div>
                         </div>

                         <div class="card three">
                              <div class="box">
                                  <i class="fas fa-shopping-cart"></i>
                                  <div class="text">Site Web</div> 
                                  <p><a href="http://mourad.great-site.net/" target="_blank">Site de E-commerce</a></p>
                                  <a href="http://mourad.great-site.net/" target="_blank"><img src="Images/pointer.png" width="20px"></a>
                                   
                              </div>
                         </div>
                   </div>
              </div>

         </section>



          <!-- sction compétences -->

          <section class="skills" id="skills">
              <div class="max-width">
                   <h2 class="title">Compétences</h2>  
                   <div class="skills-content">

                        <div class="column left">
                             <div class="text">Mes Compétences.</div>
                             
                                  <p>
                                     En ce qui concerne le développement Web je maîtrise les bases du front-end 
                                     et du back-end, tout en ayant une motivation a m'améliorer dans ce domaine
                                     dans lequel je me suis découvert une vrai passion   
                                     <span id="dots">...</span><span id="more">
                                     .<br>J'effectue actuellement une formation en langage de programmation C 
                                     qui arrivera à terme en fin décembre. Elle m'a permis d'acquérir les connaissances 
                                     essentiels de ce langage. Ce qui est des logiciel j'ai une certaine maîtrise
                                     de Adobe Illustrator que j'utilise pour mes Arts Digital.</span></p>

                                     <button onclick="myFunction()" id="myBtn">Lire plus</button>

                                     <!--petit script javaScript pour le bouton voir plus-->
                                     <script type="text/javascript">
                                         function myFunction() {
                                             var dots = document.getElementById("dots");
                                             var moreText = document.getElementById("more");
                                             var btnText = document.getElementById("myBtn");

                                             if (dots.style.display === "none") {
                                             dots.style.display = "inline";
                                             btnText.innerHTML = "Lire plus";
                                             moreText.style.display = "none";
                                             } else {
                                             dots.style.display = "none";
                                             btnText.innerHTML = "Lire moins";
                                             moreText.style.display = "inline";
                                             }
                                             } 
                                     </script>
                                    
                                                                                                                                                
                        </div>
                       


                        <div class="column right">

                            <p>Développement Web :</p>

                              <div class="bars">
                                 <div class="info">
                                      <span>HTML</span>
                                      <span>85%</span>
                                 </div>
                                 <div class="line html"></div>
                              </div>
                                                           
                              <div class="bars">
                                 <div class="info">
                                      <span>CSS</span>
                                      <span>55%</span>
                                 </div>
                                 <div class="line css"></div>
                              </div>
                                                           
                              <div class="bars">
                                 <div class="info">
                                      <span>JavaScript</span>
                                      <span>65%</span>
                                 </div>
                                 <div class="line js"></div>
                              </div>
                                                           
                              <div class="bars">
                                 <div class="info">
                                      <span>PHP</span>
                                      <span>60%</span>
                                 </div>
                                 <div class="line php"></div>
                              </div>
                                                           
                              <div class="bars">
                                 <div class="info">
                                      <span>SQL</span>
                                      <span>80%</span>
                                 </div>
                                 <div class="line sql"></div>
                              </div>

                              <div class="bars">
                                 <div class="info">
                                      <span>MySQL</span>
                                      <span>80%</span>
                                 </div>
                                 <div class="line mysql"></div>
                              </div>


                              <p>Autres langages de programmation :</p>

                              <div class="bars">
                                 <div class="info">
                                      <span>C</span>
                                      <span>60%</span>
                                 </div>
                                 <div class="line c"></div>
                              </div>


                              <p>Logiciels :</p>

                              <div class="bars">
                                 <div class="info">
                                      <span>Adobe Photoshop</span>
                                      <span>18%</span>
                                 </div>
                                 <div class="line photoshop"></div>
                              </div>
                              
                              <div class="bars">
                                 <div class="info">
                                     <span>Adobe Illustrator</span>
                                     <span>50%</span>
                                 </div>
                                 <div class="line illustrator"></div>
                              </div>
                                 
                        </div>

                   </div>                  
              </div>
          </section>




          <!-- section contact -->

          <section class="contact" id="contact">
               <div class="max-width">
                    <h2 class="title">Contactez moi</h2>
                    <div class="contact-content">

                       <div class="column left">
                          <div class="text">A moi de vous connaitre</div>
                              <p>Si vous voulez rentrer en contact avec moi n'hesitez pas à m'envoyer un mail qui est ci-dessous.</p>
                              <div class="icons">

                                   <div class="row">
                                        <i class="fas fa-user"></i>
                                        <div class="info">
                                             <div class="head">Nom</div>
                                             <div class="sub-title">Saidani Mourad</div>
                                        </div>                                        
                                   </div>

                                   <div class="row">
                                        <i class="fas fa-map-marker-alt"></i>
                                        <div class="info">
                                             <div class="head">Adresse</div>
                                             <div class="sub-title">Tizi-Ouzou, Algérie</div>
                                        </div>                                        
                                   </div>

                                   <div class="row">
                                        <i class="fas fa-envelope"></i>
                                        <div class="info">
                                             <div class="head">E-mail</div>
                                             <div class="sub-title">mourad.saidani.2022@gmail.com</div>
                                        </div>                                        
                                   </div>

                              </div>                              
                       </div>


                         <div class="column right">
                                        <div class="text">Envoyez moi un message</div>
                                        <form action="#">
                                             <div class="fields">

                                                  <div class="field name">
                                                       <input type="text" placeholder="Nom" required>                       
                                                  </div>
                                                  
                                                  <div class="field email">
                                                       <input type="email" placeholder="E-mail" required>                       
                                                  </div>
                                             </div>

                                                  <div class="field">
                                                       <input type="text" placeholder="Objet" required>                       
                                                  </div>

                                                  <div class="field textarea">
                                                       <textarea  cols="30" rows="10" placeholder="Message" required></textarea>                  
                                                  </div>

                                                  <div class="button">
                                                       <button type="submit">Envoyer</button>
                                                  </div>

                                             
                                       </form>
                                   </div>

                         </div>
                    </div>

               </section>




               <!-- section du footer -->
                           <footer>
                              <div class="footer-content">
                                   <ul class="socials">
                                        <li><a href="https://www.linkedin.com/in/mourad-saidani-4356b7225/" target="_blank"><i class="fab fa-linkedin"></i></a></li>
                                        <li><a href="https://www.facebook.com/ghiles.saidani.1" target="_blank"><i class="fab fa-facebook"></i></a></li>
                                        <li><a href="https://www.instagram.com/ghighi_dz/?hl=fr" target="_blank"><i class="fab fa-instagram"></i></a></li>                   
                                   </ul>
                              </div>      

                                 <div class="footer-bottom">
                                       <span>Créer par<a href="#"> Saidani Mourad</a> | <span class="far fa-copyright"></span>2022.</span>
                                  </div>                             
                            </footer>


          <script src="script.js"></script>    <!--lien vers Le script Jquery-->
     
 </body>

</html>