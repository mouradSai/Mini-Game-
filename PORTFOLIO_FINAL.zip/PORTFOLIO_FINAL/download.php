<?php


header("content-type: document/pdf");
header("content-Disposition: attachment; filename='CV.pdf'");

readfile("docu/CV.pdf");